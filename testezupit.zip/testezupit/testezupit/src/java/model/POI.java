/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Daiane
 */
public class POI {
    
    

    String nome;
    int x;
    int y;
    
    
    
    
    public POI(){
		
	}
	
    public POI(String nome, int x, int y){
		this.nome= nome;
		this.x = x;
		this.y=y;
		
	}

    
    
 public void setx(String nome) {
     this.nome = nome;
	}
public String getNome() {
     return this.nome;
	}
    
 public void setx(int x) {
     this.x = x;
	}
 public int getx() {
    return this.x;
	}
   
 public void sety(int y) {
     this.y = y;
	}
 public int gety() {
      return this.y;
        }
}
