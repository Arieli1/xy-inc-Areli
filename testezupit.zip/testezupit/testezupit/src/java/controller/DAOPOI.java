/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Conexao;
import model.POI;

/**
 *
 * @author Daiane
 */
public class DAOPOI {
    
 public Conexao conectar;
 
	
	public void adiciona(POI p) throws SQLException {
		
		

		String sql = "insert into poi "
				+ "(nomePOI,coordenadaX,coordenadaY)" + " values (?,?,?)";

             conectar.st = conectar.con.prepareStatement(sql);
                                  
                 conectar.st.setString (1, p.getNome());
                 conectar.st.setInt(2, p.getx());
                 conectar.st.setInt(3, p.gety());
                     
	}

	
    
}
