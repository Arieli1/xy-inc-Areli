/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Conexao;
import model.POI;

/**
 *
 * @author Daiane
 */
@WebServlet(name = "DAO", urlPatterns = {"/DAO"})
public class DAO extends HttpServlet {
 POI p;
    public Conexao conectar;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter() ;
        
           p = new POI();
       conectar =  new Conexao(); 
       
         String Nome = request.getParameter("nome");
        int x = Integer.parseInt(request.getParameter("x"));
      int y = Integer.parseInt(request.getParameter("y"));
       
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet DAO</title>");            
            out.println("</head>");
            out.println("<body>");
             out.println( inserirPOI());
             out.println("<a href='index.jsp'>HOME</a>");
            out.println("</body>");
            out.println("</html>");
        
    }
    
    
      private String retorno, sql2;
    
	public String inserirPOI() {
                conectar = new Conexao ();
                
		retorno = "POI cadastrado com sucesso!";
                        sql2 = "insert into POI (nomepoi,x,y) values (?,?,?)";
		if (conectar.getConnection()) {
			try {
		conectar.st = conectar.con.prepareStatement(sql2);
                                  
                 conectar.st.setString (1, p.getNome());
                 conectar.st.setInt(2, p.getx());
                 conectar.st.setInt(3, p.gety());
                     
                 
                   
                   int qt = conectar.st.executeUpdate();
                                   if (qt == 0) {
                                          retorno = "Falha na inclusão do POI";
                                   }
                                   conectar.close();
                           } catch (Exception e) {
                                  retorno= "Falha na inclusão do POI" + e.toString();
                           }
	}


		
	

		return retorno;
    
    }

    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
