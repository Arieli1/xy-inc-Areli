/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Daiane
 */
public class Conexao {
  public Connection con = null;
	public PreparedStatement st = null;
	public ResultSet rs = null;

   private final String DRIVER = "com.mysql.jdbc.Driver";
	private final String BANCO = "zup";
	private final String SERVIDOR = "localhost";
        private final String URL = "jdbc:mysql://localhost:3306/zup";

	private final String LOGIN = "root";
	private final String SENHA = "";
        //127.0.0.1
	public boolean getConnection() {

		try {
			Class.forName(DRIVER);
			con = DriverManager.getConnection(URL,LOGIN,SENHA);
			System.out.println("Conectado ");
			return true;

		} catch (SQLException e) {
			System.out.println("Falha na conexão com o banco! \n"
					+ e.toString());
			return false;
		} catch (ClassNotFoundException e) {
			System.out.println("Classe não encontrada."+ e.toString());
			return false;
		}

	}
public void close() {
try {
			if(rs!= null){
				rs.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
		if(st!= null){
				st.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	//	try {
			if(con!= null){
	//			con.close();
	//			System.out.println("Desconectado.");
	//	}

//		} catch (Exception e) {
//	e.printStackTrace();
		}

	}
	
	public static void main(String[] args) {
	Conexao bd = new Conexao();
		bd.getConnection();
		bd.close();
	}
    

}

