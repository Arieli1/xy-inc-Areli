/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Conexao;
import model.POI;

/**
 *
 * @author Usuario
 */
@WebServlet(name = "DAO", urlPatterns = {"/DAO"})
public class DAO extends HttpServlet {
public Conexao conectar;
POI p;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    String men2,sql2,men3,sql3,sql4,men4,nomepoi;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
           /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet DAO</title>");            
            out.println("</head>");
            out.println("<body>");
           
         p = new POI ();
        conectar = new Conexao ();
        
        String nome= request.getParameter("nome");
     
        int x = Integer.parseInt(request.getParameter("x"));
        int y = Integer.parseInt(request.getParameter("y"));
        String botao = request.getParameter("acao");
        String distancia = request.getParameter("distancia");
       
        
        
        
     p.setnome(nome);
     p.setx(x);
     p.sety(y);
     
///Comparase os valores são negativos
     
     if (x<0 || y<0)
     {         
          out.println("<h1>Campos de coordenada x e y devem ser positivos </h1>");
          
     }
     else {
if (botao.equals("Cadastro")){
            
    //Inclusão de registro
            conectar = new Conexao ();
                
		  men2 = "Inserido com sucesso!";
                        sql2 = "insert into poi (nomepoi,x,y)  values (?,?,?)";
		if (conectar.getConnection()) {
			try {
				conectar.st = conectar.con.prepareStatement(sql2);
                                  
                
                 conectar.st.setString (1, p.getNome());
                 conectar.st.setInt (2,   p.getx());
                 conectar.st.setInt (3,   p.gety());
                
            
                   int qt = conectar.st.executeUpdate();
                                   if (qt == 0) {
                                           men2 = "Falha na inclusão";
                                   }
                                   conectar.close();
                           } catch (Exception e) {
                                   men2 = "Falha na inclusão " + e.toString();
                           }
	}


	   System.out.println(men2);	
	
     out.println("<h1>"+men2+"</h1>"); 
}
     }
     
if (botao.equals("ATUALIZAR")) {
    conectar = new Conexao ();
        //Atualiza registro
		  men3 = "Alterado com sucesso!";
                        sql3 = "update poi set nomepoi=?,x=?,y=? WHERE nomepoi=?";
		if (conectar.getConnection()) {
			try {
				conectar.st = conectar.con.prepareStatement(sql3);
                                  
                conectar.st.setString (1,   p.getNome());
                conectar.st.setInt (2,   p.getx());
                conectar.st.setInt (3,   p.gety());
                conectar.st.setString (4,   p.getNome());
             
                            System.out.println(sql3);
                   int qt = conectar.st.executeUpdate();
                                   if (qt == 0) {
                                           men3 = "Falha na atualização";
                                   }
                                   conectar.close();
                           } catch (Exception e) {
                                   men3 = "Falha na atualização " + e.toString();
                           }
	}

   System.out.println(men3);	
   
            out.println("<h1>"+men3+"</h1>");
              
    
}
if (botao.equals("EXCLUIR")) {
    conectar = new Conexao ();
                ///Exclusão de registro
		  men4 = "Removido com sucesso!";
                        sql4 = "Delete from poi where nomepoi = ?";
		if (conectar.getConnection()) {
			try {
				conectar.st = conectar.con.prepareStatement(sql4);
                                  
                 conectar.st.setString (1,   p.getNome());
                   
                   int qt = conectar.st.executeUpdate();
                                   if (qt == 0) {
                                           men4 = "Falha na remoção";
                                   }
                                   conectar.close();
                           } catch (Exception e) {
                                   men3 = "Falha na remoção " + e.toString();
                           }
	}

   System.out.println(men4);	
   
            out.println("<h1>"+men4+"</h1>");
        
}
if (botao.equals("DISTANCIA")) {
    //Calculo de distancia entre os pontos, deve mostar o POI mais proximo
    conectar = new Conexao ();
                out.println("<h1>NOME DO POI MAIS PROXIMO </h1>");         
		if(conectar.getConnection()){
			String sql = "SELECT nomepoi FROM poi WHERE round(sqrt( pow((x - "+x+"), 2) + pow((y - "+y+"),2)), 2) <= "+distancia+"" ;

			try{
				conectar.st = conectar.con.prepareStatement(sql);
				conectar.rs = conectar.st.executeQuery();
				while(conectar.rs.next()){
                        		
                                     String poi = conectar.rs.getString("nomepoi");
                                        System.out.println(poi);	
            out.println(""+poi+"<br>");                                  
                                    	}

                                   System.out.println(nomepoi);	
   
   
    
                                conectar.close();
			}
			catch(SQLException erro){
				System.out.println("Falha: "+erro.toString());
			}
		}
                else {

			System.out.println("Não foi possivel conectar!");
		}
}
          out.println ("<a href='index.jsp'>Voltar</a> ");  
          out.println("</body>");
          out.println("</html>");
       
  }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
